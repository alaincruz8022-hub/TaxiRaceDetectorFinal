package com.alain.taxiracedetector;

import android.content.Context;
import android.content.SharedPreferences;

public final class DetectorStore {
    private static final String PREFS = "taxi_detector_store";
    private static final String LAST_RESULT = "last_result";
    private DetectorStore() {}

    public static void saveResult(Context context, String result) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(LAST_RESULT, result).apply();
    }

    public static String getLastResult(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return preferences.getString(LAST_RESULT, "Todavía no se han recibido ofertas.");
    }
}
