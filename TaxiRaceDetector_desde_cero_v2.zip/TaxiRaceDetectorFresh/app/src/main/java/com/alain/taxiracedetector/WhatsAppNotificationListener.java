package com.alain.taxiracedetector;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WhatsAppNotificationListener extends NotificationListenerService {
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        String packageName = sbn.getPackageName();
        // WhatsApp and WhatsApp Business only. No messages are sent and no notification is selected.
        if (packageName == null || !(packageName.equals("com.whatsapp") || packageName.equals("com.whatsapp.w4b"))) return;

        Notification notification = sbn.getNotification();
        Bundle extras = notification.extras;
        if (extras == null) return;
        CharSequence title = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (text == null) text = extras.getCharSequence(Notification.EXTRA_TEXT);
        CharSequence lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES) == null ? null
                : joinLines(extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES));
        String body = text != null ? text.toString() : (lines != null ? lines.toString() : "");
        String full = (title == null ? "" : title.toString() + "\n") + body;
        if (full.trim().isEmpty()) return;

        RaceDecision decision = RaceParse.evaluate(full);
        String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        String result = time + "\n" + (decision.airportRelated ? "CARRERA DE AEROPUERTO DETECTADA" : "OFERTA DESCARTADA")
                + "\n" + decision.reason + "\n\n" + decision.text;
        // Keep the latest result available for the app UI. No automated reply/action.
        DetectorStore.saveResult(this, result);
    }

    private CharSequence joinLines(CharSequence[] lines) {
        StringBuilder result = new StringBuilder();
        for (CharSequence line : lines) {
            if (line != null) {
                if (result.length() > 0) result.append('\n');
                result.append(line);
            }
        }
        return result;
    }
}
