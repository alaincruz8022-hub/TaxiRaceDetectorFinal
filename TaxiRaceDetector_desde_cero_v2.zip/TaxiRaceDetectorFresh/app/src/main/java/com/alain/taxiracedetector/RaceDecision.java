package com.alain.taxiracedetector;

public class RaceDecision {
    public final boolean airportRelated;
    public final String reason;
    public final String text;

    public RaceDecision(boolean airportRelated, String reason, String text) {
        this.airportRelated = airportRelated;
        this.reason = reason;
        this.text = text;
    }
}
