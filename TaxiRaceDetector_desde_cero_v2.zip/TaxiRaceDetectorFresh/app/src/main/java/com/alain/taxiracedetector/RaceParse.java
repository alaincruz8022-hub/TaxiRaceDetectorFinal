package com.alain.taxiracedetector;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

public final class RaceParse {
    private static final Pattern HAV_TOKEN = Pattern.compile("(^| )hav($| )");
    private RaceParse() {}

    // Every eligible WhatsApp notification is inspected. Only airport-related offers are retained.
    // This is a first-pass keyword filter; real offer examples are needed to reduce false positives/negatives.
    public static RaceDecision evaluate(String originalText) {
        String text = originalText == null ? "" : originalText.trim();
        String normalized = normalize(text);
        if (normalized.isEmpty()) {
            return new RaceDecision(false, "Notificación sin texto útil", text);
        }

        boolean airport = containsAny(normalized,
                "aeropuerto", "airport", "jose marti", "jose marty", "jose marti international",
                "terminal 1", "terminal 2", "terminal 3", "terminal internacional",
                "salidas internacionales", "llegadas internacionales", "recogida aeropuerto",
                "traslado aeropuerto", "hacia el aeropuerto", "desde el aeropuerto",
                "airport pickup", "airport transfer", "varadero airport", "terminal aerea");
        if (!airport && HAV_TOKEN.matcher(normalized).find()) airport = true;

        if (!airport) {
            return new RaceDecision(false, "Descartada: no se identificó relación con aeropuerto", text);
        }
        return new RaceDecision(true, "Posible carrera de aeropuerto; revisar manualmente", text);
    }

    private static boolean containsAny(String text, String... clues) {
        for (String clue : clues) {
            if (text.contains(clue)) return true;
        }
        return false;
    }

    private static String normalize(String input) {
        String value = Normalizer.normalize(input.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        value = value.replaceAll("\\p{M}+", "");
        return value.replaceAll("[^a-z0-9]+", " ").trim();
    }
}
