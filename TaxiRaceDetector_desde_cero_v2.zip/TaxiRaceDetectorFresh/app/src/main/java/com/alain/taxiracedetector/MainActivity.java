package com.alain.taxiracedetector;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 32, 28, 24);

        TextView title = new TextView(this);
        title.setText("TaxiRaceDetector v0.2 — modo prueba");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView description = new TextView(this);
        description.setText("Analiza las notificaciones de WhatsApp y conserva las ofertas relacionadas con aeropuerto. No envía mensajes ni selecciona ofertas automáticamente.");
        description.setTextSize(16);
        description.setPadding(0, 20, 0, 20);
        layout.addView(description);

        Button settings = new Button(this);
        settings.setText("Activar acceso a notificaciones");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        layout.addView(settings);

        Button refresh = new Button(this);
        refresh.setText("Actualizar resultado");
        refresh.setOnClickListener(v -> refreshResult());
        layout.addView(refresh);

        status = new TextView(this);
        status.setTextSize(14);
        status.setPadding(0, 16, 0, 12);
        layout.addView(status);

        result = new TextView(this);
        result.setTextSize(16);
        result.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(result);
        layout.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(layout);
        refreshResult();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshResult();
    }

    private void refreshResult() {
        result.setText(DetectorStore.getLastResult(this));
        status.setText("Filtro principal: carreras relacionadas con aeropuerto. Revisa manualmente el resultado; esta versión es de prueba.");
    }
}
