# TaxiRaceDetector v0.2 — modo prueba

Proyecto Android para probar la detección de ofertas en notificaciones de WhatsApp y WhatsApp Business.

## Funcionamiento actual
- Inspecciona el texto de las notificaciones de WhatsApp y WhatsApp Business.
- Marca como candidata una notificación si detecta indicios textuales de aeropuerto (por ejemplo, aeropuerto, airport, José Martí, terminales o HAV como palabra independiente).
- Marca las demás como descartadas.
- Guarda y muestra el resultado más reciente dentro de la aplicación.
- No envía mensajes, no responde “YO” y no selecciona ofertas automáticamente.

## Limitaciones de esta versión
Esta es una base inicial de prueba, no un detector definitivo. La detección usa palabras clave y puede pasar por alto una oferta redactada de forma indirecta o marcar un falso positivo. Debe probarse con ejemplos reales. Las reglas de pasajeros, equipaje, precio mínimo y horario aún no están implementadas como filtros definitivos.

## Compilación desde móvil
El workflow `.github/workflows/build-apk.yml` configura Java 17, Gradle 8.9 y Android SDK, y ejecuta `gradle clean assembleDebug`. Desde GitHub, abre **Actions**, selecciona **Build TaxiRaceDetector APK** y pulsa **Run workflow**. El APK se publica como artefacto descargable si la compilación termina correctamente.

## Activar acceso a notificaciones
Después de instalar el APK, abre la app, pulsa **Activar acceso a notificaciones** y habilita TaxiRaceDetector en Android.
